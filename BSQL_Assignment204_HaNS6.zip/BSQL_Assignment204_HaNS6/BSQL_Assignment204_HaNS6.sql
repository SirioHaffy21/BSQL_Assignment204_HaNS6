-- Create a new database called 'MovieCollection'
-- Connect to the 'master' database to run this snippet
USE master
GO
-- Create the new database if it does not exist already
IF NOT EXISTS (
    SELECT [name]
        FROM sys.databases
        WHERE [name] = N'MovieCollection'
)
CREATE DATABASE MovieCollection_HaNS6
GO

--------------------QUESTION 1-----------------------
-- Create a new table called '[Movie]' in schema '[dbo]'
-- Drop the table if it already exists
IF OBJECT_ID('[dbo].[Movie]', 'U') IS NOT NULL
DROP TABLE [dbo].[Movie]
GO
-- Create the table in the specified schema
CREATE TABLE [dbo].[Movie]
(
    [MovieId] INT NOT NULL PRIMARY KEY IDENTITY(1,1), -- Primary Key column
    [MovieName] NVARCHAR(50) NOT NULL,
    [Duration] TIME CHECK(Duration > '01:00:00'),
    Genre INT CHECK(Genre BETWEEN 1 AND 8),
    Director NVARCHAR(50) NOT NULL,
    Amount MONEY CHECK(Amount > 0)
    -- Specify more columns here
);
GO

CREATE TABLE Actor
(
    ActorId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    ActorName NVARCHAR(50) NOT NULL,
    Age INT CHECK(AGE > 0),
    AverageSalary MONEY CHECK(AverageSalary > 0),
    Nationality NVARCHAR(100) 
)
GO

CREATE TABLE ActedIn
(
    ActorId INT FOREIGN KEY REFERENCES Actor(ActorId),
    MovieId INT FOREIGN KEY REFERENCES Movie(MovieId),
    Note TEXT,
)
GO
--------------QUESTION 2
-----1. Add an ImageLink
ALTER TABLE Movie
ADD ImageLink VARCHAR(200) UNIQUE
GO

-----2. INSERT DATA
-----Actor
INSERT INTO Actor(ActorName, Age, AverageSalary, Nationality) VALUES
('Nguyen Van Ha',55,12000,'Viet Nam'),
('Stan Lee',60,145000,'USA'),
(N'Victor Vũ',45,20000,'China'),
('Nguyen Thi Lan',35,2000,'Han Quoc'),
('Le Trinh',32,9000,'Viet Nam'),
(N'Nguyễn Ánh',55,12000,'Viet Nam')
GO

SELECT * FROM Actor
-----Movie
INSERT INTO Movie(MovieName, Duration, Genre, Director, Amount, ImageLink) VALUES
(N'Sống chung với mẹ chồng','02:45:00',5,'NGUYEN SY HA',600000, 'songchung.png'),
(N'Iron man','02:03:00',8,'PETER PARKER',1000000,'irm.png'),
(N'Cô gái ngày hôm qua','04:10:00',3,'Nguyen Van Son',50000, 'hihi.png'),
(N'Mắt biếc','01:55:00',6,'Le Van Luyen',400000, 'matbiec.png'),
(N'Tây du ký','02:56:00',5,'Ngo Thua An',600000, 'tdk.png'),
(N'Ngược dòng nước mắt','01:25:00',5,'NGUYEN SY HA',300000, 'ngdongnuocmat.png'),
(N'Kịch câm','01:45:00',1,'NGUYEN SY HA',300000, 'kich.png')
GO

SELECT * FROM Movie
----ActIn
INSERT INTO ActedIn(ActorId, MovieId) VALUES
(1, 3),
(5, 3),
(3, 3),
(2, 4),
(6, 5),
(4, 5),
(6, 8),
(2, 6),
(1, 7),
(4, 4),
(2, 9),
(3, 9),
(4, 9)

--------QUESTION 3
-----1.
SELECT * FROM Actor a WHERE a.Age > 50
GO

-----2.
SELECT a.ActorName, a.AverageSalary 
FROM Actor a
ORDER BY a.AverageSalary
GO

-----3.
SELECT a.ActorName, m.MovieName
FROM ActedIn ai 
INNER JOIN Movie m ON m.MovieId = ai.MovieId
INNER JOIN Actor a ON ai.ActorId = a.ActorId
WHERE a.ActorName LIKE 'Nguyen Thi Lan'
GO

-----4.
SELECT m.MovieId, m.MovieName, COUNT(ai.ActorId) AS QuantityActor
FROM Movie m INNER JOIN ActedIn ai ON m.MovieId = ai.MovieId
WHERE m.Genre = 1
GROUP BY m.MovieId, m.MovieName
HAVING COUNT(ai.ActorId) >= 3
